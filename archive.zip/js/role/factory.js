function factory(baseOptions){
    var baseOptions=baseOptions;
    return function(which,options){
        options=options||{};
        until.extend(options,baseOptions);
        // console.log(new window[which](options));
        return new window[which](options);
    }
}
