function Music(options){
    this.bgMusic=options.bgMusic
}

Music.prototype={
    bgMusicPlay:function(){
        
    }
}